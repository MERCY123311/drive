//
//  ResultTableViewCell.swift
//  Soldatov
//
//  Created by Солдатов Иван Сергеевич on 23/1/2023.
//

import UIKit

class ResultTableViewCell: UITableViewCell {

    @IBOutlet weak var namePlayer: UILabel!
    @IBOutlet weak var gameResult: UILabel!
    @IBOutlet weak var timeResult: UILabel!
    
   
}
